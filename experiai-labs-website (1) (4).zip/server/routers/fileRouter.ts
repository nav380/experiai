import { z } from "zod";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { files } from "../../drizzle/schema";
import { storagePut, storageGet } from "../storage";
import { eq } from "drizzle-orm";

/**
 * File Storage Router
 * Handles file uploads, retrieval, and metadata management
 */
export const fileRouter = router({
  /**
   * Upload a file to storage and save metadata to database
   * Accepts base64 encoded file data
   */
  upload: protectedProcedure
    .input(
      z.object({
        filename: z.string().min(1).max(255),
        fileData: z.string(), // base64 encoded file data
        mimeType: z.string().default("application/octet-stream"),
        category: z.enum(["team-photo", "marketing-asset", "content", "other"]).default("other"),
        teamMemberId: z.string().optional(),
      })
    )
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        // Convert base64 to buffer
        const buffer = Buffer.from(input.fileData, "base64");
        const fileSize = buffer.length;

        // Generate S3 key with timestamp and category
        const timestamp = Date.now();
        const sanitizedFilename = input.filename.replace(/[^a-zA-Z0-9.-]/g, "_");
        const s3Key = `files/${input.category}/${timestamp}-${sanitizedFilename}`;

        // Upload to storage
        const { url } = await storagePut(s3Key, buffer, input.mimeType);

        // Save metadata to database
        await db.insert(files).values({
          filename: input.filename,
          s3Key,
          url,
          mimeType: input.mimeType,
          fileSize,
          uploadedBy: ctx.user?.id,
          category: input.category,
          teamMemberId: input.teamMemberId,
        });

        return {
          success: true,
          filename: input.filename,
          url,
          s3Key,
          fileSize,
        };
      } catch (error) {
        console.error("[File Upload] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to upload file"
        );
      }
    }),

  /**
   * Get file metadata by ID
   */
  getById: protectedProcedure
    .input(z.object({ fileId: z.number() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        const result = await db
          .select()
          .from(files)
          .where(eq(files.id, input.fileId))
          .limit(1);

        return result.length > 0 ? result[0] : null;
      } catch (error) {
        console.error("[File Get] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to retrieve file"
        );
      }
    }),

  /**
   * List files by category
   */
  listByCategory: protectedProcedure
    .input(
      z.object({
        category: z.enum(["team-photo", "marketing-asset", "content", "other"]),
        limit: z.number().default(50),
      })
    )
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        const result = await db
          .select()
          .from(files)
          .where(eq(files.category, input.category))
          .limit(input.limit);

        return result;
      } catch (error) {
        console.error("[File List] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to list files"
        );
      }
    }),

  /**
   * Get files for a specific team member
   */
  getTeamMemberFiles: protectedProcedure
    .input(z.object({ teamMemberId: z.string() }))
    .query(async ({ input }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        const result = await db
          .select()
          .from(files)
          .where(eq(files.teamMemberId, input.teamMemberId));

        return result;
      } catch (error) {
        console.error("[Team Member Files] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to retrieve team member files"
        );
      }
    }),

  /**
   * Delete a file (admin only)
   */
  delete: protectedProcedure
    .input(z.object({ fileId: z.number() }))
    .mutation(async ({ input, ctx }) => {
      try {
        const db = await getDb();
        if (!db) {
          throw new Error("Database not available");
        }

        // Check if user is admin
        if (ctx.user?.role !== "admin") {
          throw new Error("Only admins can delete files");
        }

        // Get file to retrieve S3 key
        const fileRecord = await db
          .select()
          .from(files)
          .where(eq(files.id, input.fileId))
          .limit(1);

        if (fileRecord.length === 0) {
          throw new Error("File not found");
        }

        // Delete from database
        await db.delete(files).where(eq(files.id, input.fileId));

        return {
          success: true,
          deletedFileId: input.fileId,
        };
      } catch (error) {
        console.error("[File Delete] Error:", error);
        throw new Error(
          error instanceof Error ? error.message : "Failed to delete file"
        );
      }
    }),
});
